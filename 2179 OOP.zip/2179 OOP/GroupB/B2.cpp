/*
Author : Divyajyoti Ukirde
Roll No. 2179
Batch : H1
 */

#include<iostream>
using namespace std;

template<class T>

void sort(T x[10])
{
	int min;
	T temp;
	for(int i=0;i<9;i++)
	{	min=i;
	for(int j=i+1;j<10;j++)
	{	
		if(x[min]>x[j])
		{
		min=j;
		}
	}
		//swap(&min, &x[i])
		temp=x[min];
		x[min]=x[i];
		x[i]=temp;
	}
	
}


/*void swap(T &x, T &y)
{
	T temp;
	temp=x;
	x=y;
	y=temp;
}*/

int main()
{
	int b[10];
	float a[10];
	cout<<"Enter integers \n";
	for(int i=0;i<10;i++)
	{
		cin>>b[i];
	}
	sort(b);
	cout<<"Sorted array \n";
	for(int i=0;i<10;i++)
	{
		cout<<b[i]<<"  ";
	}
	cout<<"Enter decimals\n";
	for(int i=0;i<10;i++)
	{
		cin>>a[i];
	}
	sort(a);
	cout<<"Sorted array \n";
	for(int i=0;i<10;i++)
	{
		cout<<a[i]<<"  ";
	}

return 0;
}

//OUTPUT
/*[pict@localhost GroupB]$ ./a.out
Enter integers 
5     
3
8
7
11
6
4
9
10
2
Sorted array 
2  3  4  5  6  7  8  9  10  11  
Enter decimals
2.5
6.2
4.4
4.3
6.8
8.8
7.5
1.2
0.6
3.3
Sorted array 
0.6  1.2  2.5  3.3  4.3  4.4  6.2  6.8  7.5  8.8 
*/
