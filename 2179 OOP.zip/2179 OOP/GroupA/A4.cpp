/*
Author : Divyajyoti Ukirde
Roll No. 2179
Batch : H1
 */

#include<iostream>
#include<string.h>
using namespace std;

	class personal
{
    protected:
    	int i;
    	char name[20],address[50];
    	int d,m,y;
    	long long ph;	
    
    public:
    	personal()
    	{
    		i=0;
		}
    void display()
    {
        cout<<"\n Name:"<<name;
        cout<<"\n Address: ";
        cout<<address;
        cout<<"\n DOB: "<<d<<"/"<<m<<"/"<<y;
        cout<<"\n Phone no.: "<<ph;
        i=i+1;
    }
};

class professional
{
    protected:
    	int i;
    	char company[20],work[20];	
    public:
    	professional()
    	{
    		i=0;
		}
    void display()
    {
        cout<<"\n Company: ";
        cout<<company;
        cout<<"\n Designation: ";
        cout<<work; 
		i=i+1;       
    }

};

class academic
{
    protected:
    	int i;
    char qual[10];
    float ssc,hsc;
    public:
    	academic()
    	{
    		i=0;
		}
    void display()
    {
        cout<<"\n Qualification: "<<qual;
        cout<<"\n SSC%:"<<ssc<<"\t HSC%:"<<hsc;
        i=i+1;
    }
};

class biodata : public personal, public professional, public academic
{
	int i;
    public:
    	biodata()
	{
		i=0;
	}
    void getdata()
    {    
        cout<<"Enter Biodata: ";    
        cout<<"Enter Name: ";
        cin>>name; 
        cin.ignore();
        cout<<"\n Enter Address: ";
        cin.getline(address,50);
        cout<<"\n Enter DOB(dd/mm/yy)";
        cin>>d>>m>>y;    
        cout<<"\n Enter phone no.: ";
        cin>>ph;
        cout<<"\n Enter Qualification: ";
        cin>>qual;
        cout<<"\n Enter SSC and HSC %: ";
        cin>>ssc>>hsc;
        cout<<"\n Enter Company Name: ";
        cin.ignore();
        cin.getline(company,20);
        cin.ignore();
        cout<<"\n Enter Designation: ";
        cin.getline(work,20);
        i=i+1;
    }    
    void display()
    {
        personal::display();
        professional::display();
        academic::display();
    }
};


int main()
{    
	biodata b1[100];
	int i=0;
    char x;
    do
    {
    b1[i].getdata();
    cout<<"Want to enter data? y/n";
    cin>>x;
    i=i+1;
    }while(x!='n');
    
    for(int j=0;j<i;j++)
        {
        b1[j].display();	
		}
    return 0;  
}

//OUTPUT
/* Name:divya
 Address: pune dhankavdi
 DOB: 5/4/98
 Phone no.: 9898987898
 Company: Morgan Stanley
 Designation: Software Engineer
 Qualification: B.Tech
 SSC%:97	 HSC%:89
 Name:Medha
 Address: pune katraj
 DOB: 31/3/99
 Phone no.: 8987898789
 Company: Google
 Designation: CEO
 Qualification: B.E.
 SSC%:98	 HSC%:98*/
