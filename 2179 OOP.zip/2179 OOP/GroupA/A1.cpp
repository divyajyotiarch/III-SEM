/*
Author : Divyajyoti
Roll No. 2179
Batch : H1
Assisnment no. 1
 */

# include <iostream>
using namespace std;

int main()
{
    
    int a,c;
    float n1, n2;
    jump:
    cout << "Enter 1.Addtion 2.Subtraction 3.Multiplication 4.Division";
    cin >> c;

    cout << "Enter two operands: ";
    cin >> n1 >> n2;

    switch(c)
    {
        case 1:
            cout <<"sum of no.s is"<<n1+n2<<endl;
            break;

        case 2:
            cout <<"difference of no.s is"<< n1-n2<<endl;
            break;

        case 3:
            cout <<"product of no.s is" <<n1*n2<<endl;
            break;

        case 4:
            cout << "division of no.s is"<<n1/n2<<endl;
            break;

        default:
            
            cout << "invalid";
            break;
    }
    cout<<" enter 1 for yes and 0 or no";
    cin>>a;
    if(a==1)
    {
    	goto jump;

    }
    return 0;
}

//OUTPUT
/*[pict@localhost GroupA]$ g++ A1.cpp
[pict@localhost GroupA]$ ./a.out
Enter 1.Addtion 2.Subtraction 3.Multiplication 4.Division1
Enter two operands: 2 3
sum of no.s is5
 enter 1 for yes and 0 or no1
Enter 1.Addtion 2.Subtraction 3.Multiplication 4.Division3
Enter two operands: 2 3
product of no.s is6
 enter 1 for yes and 0 or no0
*/
