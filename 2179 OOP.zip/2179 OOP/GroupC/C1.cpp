#include<iostream>
#include<stack>

using namespace std;

int main()
{
	char ch;
	stack<int>s1,s2,s3;
	int carry=0,bit,sum;
	cout<<"first binary no. \n";
	do
	{	
		cout<<"Enter bit: \t";
		cin>>bit;
		s1.push(bit);
		cout<<"Want to enter one more bit? y/n \n";
		cin>>ch;
	}while(ch!='n');
	cout<<"second binary no. \n";
	do
	{	
		cout<<"Enter bit: \t";
		cin>>bit;
		s2.push(bit);
		cout<<"Want to enter one more bit? y/n \n";
		cin>>ch;
	}while(ch!='n');
	
	while(!s1.empty() && !s2.empty())
	{
		sum = (s1.top()+s2.top()+carry)%2;
		carry = (s1.top()+s2.top()+carry)/2;
		s3.push(sum);
		s1.pop(); s2.pop();
	}
	s3.push(carry);
	cout<<"Sum is \n";
	while(!s3.empty())
	{
		cout<<s3.top()<<" ";
		s3.pop();
	}
	return 0;
}
